-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema bd-hibernate-herencia
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bd-hibernate-herencia
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bd-hibernate-herencia` DEFAULT CHARACTER SET latin1 ;
USE `bd-hibernate-herencia` ;

-- -----------------------------------------------------
-- Table `bd-hibernate-herencia`.`cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd-hibernate-herencia`.`cliente` (
  `idCliente` INT NOT NULL AUTO_INCREMENT,
  `nroCliente` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`idCliente`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `bd-hibernate-herencia`.`contacto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd-hibernate-herencia`.`contacto` (
  `idContacto` INT NOT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `telefonoFijo` VARCHAR(45) NULL DEFAULT NULL,
  `movil` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idContacto`),
  CONSTRAINT `fk_Cliente`
    FOREIGN KEY (`idContacto`)
    REFERENCES `bd-hibernate-herencia`.`cliente` (`idCliente`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `bd-hibernate-herencia`.`inscripcionafip`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd-hibernate-herencia`.`inscripcionafip` (
  `idInscripcionAfip` INT NOT NULL AUTO_INCREMENT,
  `inscripcionAfip` VARCHAR(45) NOT NULL,
  `idCliente` INT NOT NULL,
  PRIMARY KEY (`idInscripcionAfip`),
  INDEX `fk_Cliente_idx` (`idCliente` ASC) VISIBLE,
  CONSTRAINT `fkcliente`
    FOREIGN KEY (`idCliente`)
    REFERENCES `bd-hibernate-herencia`.`cliente` (`idCliente`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `bd-hibernate-herencia`.`personafisica`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd-hibernate-herencia`.`personafisica` (
  `idPersonaFisica` INT NOT NULL,
  `apellido` VARCHAR(30) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `dni` INT NOT NULL,
  PRIMARY KEY (`idPersonaFisica`),
  CONSTRAINT `fk_personafisica_1`
    FOREIGN KEY (`idPersonaFisica`)
    REFERENCES `bd-hibernate-herencia`.`cliente` (`idCliente`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `bd-hibernate-herencia`.`personajuridica`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd-hibernate-herencia`.`personajuridica` (
  `idPersonaJuridica` INT NOT NULL,
  `razonSocial` VARCHAR(25) NOT NULL,
  `cuit` VARCHAR(11) NOT NULL,
  PRIMARY KEY (`idPersonaJuridica`),
  CONSTRAINT `fk_personajuridica_1`
    FOREIGN KEY (`idPersonaJuridica`)
    REFERENCES `bd-hibernate-herencia`.`cliente` (`idCliente`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;